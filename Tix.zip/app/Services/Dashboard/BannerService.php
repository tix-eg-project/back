<?php

namespace App\Services\Dashboard;

use App\Models\Banner;
use App\Helpers\MediaHelper;
use App\Enums\ProductImage;
use App\Enums\ImageEnum;
use App\Helpers\ImageManger;

class BannerService
{
    public $imageManger;
    public function __construct(ImageManger $imageManger)
    {
        $this->imageManger = $imageManger;
    }

    public function store(array $data): Banner
    {
        $data['image'] = $this->imageManger->uploadImage('banners', $data['image']);

        $banner = Banner::create(
            [
                'title' => $data['title'],
                'description' => $data['description'],
                'image' => $data['image'],

            ]
        );



        // أما لو استعملت class ثابت، فا تستدعيه مباشرة:
        // ImageEnum::IMAGE 

        return $banner;
    }

    public function update(Banner $banner, array $data): Banner
    {
        $banner->update([
            'title'       => $data['title'],
            'description' => $data['description'],
        ]);

        if (!empty($data['image'])) {
            $banner->clearMediaCollection(ImageEnum::IMAGE);

            MediaHelper::uploadMedia(
                $banner,
                $data['image'],
                ImageEnum::IMAGE,

            );
        }

        return $banner;
    }

    public function delete(Banner $banner): bool
    {
        $banner->clearMediaCollection(ImageEnum::IMAGE);
        return $banner->delete();
    }
}
