<?php

return [
    'dashboard' => 'الرئيسيه'

];
