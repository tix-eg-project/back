<?php

return [
    'dashboard' => 'Dashboard'

];
