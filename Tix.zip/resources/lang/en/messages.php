<?php

return [
    'dashboard' => 'Dashboard',


    'register_success'         => 'Registration successful',
    'verify_code_failed'       => 'Verification code failed',
    'user_not_found'           => 'User not found',
    'verify_success'           => 'Verification successful',
    'invalid_credentials'      => 'Invalid credentials',
    'email_not_verified'       => 'Email not verified',
    'login_success'            => 'Login successful',
    'email_not_registered'     => 'Email not registered',
    'account_already_verified' => 'Account already verified',
    'reset_code_sent'          => 'Reset code sent',
    'forget_password_code_sent' => 'Forgot password code sent',
    'code_expired'             => 'Code expired',
    'code_mismatch'            => 'Code mismatch',
    'reset_verify_success'     => 'Reset verification successful',
    'must_verify_code_first'   => 'Must verify code first',
    'password_reset_success'   => 'Password reset successful',

    'new_password_required' => 'The new password field is required.',
    'new_password_string'   => 'The new password must be a string.',
    'new_password_min'      => 'The new password must be at least 8 characters.',
    'new_password_confirmed' => 'The new password confirmation does not match.',

    'password_confirmation_required' => 'The password confirmation field is required.',
    'password_confirmation_string'   => 'The password confirmation must be a string.',
    'password_confirmation_min'      => 'The password confirmation must be at least 8 characters.',
    'password_confirmation_confirmed' => 'The password confirmation does not match.',


];
